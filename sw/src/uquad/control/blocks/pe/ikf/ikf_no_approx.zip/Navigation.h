#ifndef UQUAD_CONTROL_IKF_NAVIGATION_H
#define UQUAD_CONTROL_IKF_NAVIGATION_H

#include "../Navigation.h"

#include "magnetic.h"
#include "types.h"



namespace uquad
{
namespace control
{
namespace ikf
{
    class Navigation
        : public control::Navigation
    {
    public:
        
        class Registry
			: public control::Navigation::Registry
		{
		public:
			Registry();

			intrusive_ptr<control::System> createSystem() const;
		};
        
        Navigation();
        ~Navigation();
        
        bool isValid() const;
        
        system::error_code prepare();
        bool isPrepared() const;
        void unprepare();
        
        system::error_code processUQuadSensorsData(hal::UQuadSensorsData const &usd);
        
    private:
        bool m_bPrepared;
        
        uint32_t m_LoopCount;
        
        AccelSensor m_AccelSensor;
        GyroSensor m_GyroSensor;
        MagSensor m_MagSensor;
        
        MagneticBuffer m_MagBuffer;
        MagCalibration m_MagCalibration;
        
        //SV_1DOF_P_BASIC m_PressureState;
        SV_9DOF_GBY_KALMAN m_9DOFState;
    };
    
    
} //namespace ikf
} //namespace control
} //namespace uquad


#endif //UQUAD_CONTROL_MSF_NAVIGATION_H
